<?php
// Conexão com o banco de dados
require_once 'servidor.php';
// Conexão com o banco de dados
$serverName = $conteudoServidor; 
$connectionOptions = array(
    "Database" => "sistema", // Nome do banco de dados
    //"Uid" => "yadmin", // Nome de usuário
    //"PWD" => "admin" // Senha
);

// Obtém o ID do registro da requisição GET
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    try {
        
        $conn = sqlsrv_connect($serverName, $connectionOptions);

        if ($conn === false) {
            throw new Exception("Erro ao conectar ao banco de dados: " . print_r(sqlsrv_errors(), true));
        }

        $sql = "SELECT id, descricao, status, id_tipo_produto, valor, imposto, valor_imposto, valor_total FROM sistema.dbo.produto WHERE id = ?";

        $params = array($id);
        $stmt = sqlsrv_query($conn, $sql, $params);

        if ($stmt === false) {
            throw new Exception("Erro ao executar a consulta SQL: " . print_r(sqlsrv_errors(), true));
        }

        $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

        sqlsrv_free_stmt($stmt);
        sqlsrv_close($conn);

        // Retorna os dados como JSON
        header('Content-Type: application/json');
        echo json_encode($row);
        exit;

    } catch (Exception $e) {
        // Trata erros
        http_response_code(500); // Erro interno do servidor
        echo json_encode(array('error' => $e->getMessage()));
        exit;
    }
}

// Se não houver ID válido, retorna erro
http_response_code(400); 
echo json_encode(array('error' => 'ID do registro não especificado'));
exit;
?>
