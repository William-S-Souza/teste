<?php
// Digite aqui o nome do seu servidor. EX: DESKTOP-89EEUTR\\SQLEXPRESS
$conteudoServidor = "DESKTOP-89EEUTR\\SQLEXPRESS";
?>