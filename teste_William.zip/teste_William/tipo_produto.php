<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Teste - William</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

    <!-- Bootstrap Bundle (Bootstrap JS + Popper.js) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <!-- Custom styles for this page -->
    <style>
        .dataTables_wrapper .dataTables_paginate {
            display: flex;
            justify-content: flex-start;
        }
    </style>

    <style>
        .btn-group-custom {
            display: flex;
            flex-wrap: wrap;
        }

        .btn-group-custom label {
            width: calc(33.33% - 10px);
            /* Tamanho fixo de aproximadamente um terço da largura disponível */
            margin: 5px;
            /* Espaçamento entre os botões */
            border-radius: 12px;
            /* Cantos arredondados */
        }
    </style>



</head>


<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-file-code"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Teste William<sup></sup></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <!--<div class="sidebar-heading">
                Interface
            </div>-->
            <div class="sidebar-heading">
                Cadastros
            </div>

            <!-- Nav Item - Cadastros -->
            <!-- Tela - Impostos -->
            <li class="nav-item">
                <a class="nav-link" href="impostos.php">
                    <i class="fas fa-hand-holding-usd"></i>
                    <span>Impostos</span></a>
            </li>
            <!-- Tela - Tipo de Produtos -->
            <li class="nav-item">
                <a class="nav-link" href="tipo_produto.php">
                    <i class="fas fa-sitemap"></i>
                    <span>Tipos de Produto</span></a>
            </li>
            <!-- Tela - Produtos -->
            <li class="nav-item">
                <a class="nav-link" href="produto.php">
                    <i class="fas fa-suitcase"></i>
                    <span>Produtos</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Vendas
            </div>
            <!-- Nav Item - Pages Vendas -->



            <!-- Nav Item - Vendas -->
            <li class="nav-item">
                <a class="nav-link" href="venda.php">
                    <i class="fas fa-handshake"></i>
                    <span>Vendas</span></a>
            </li>

            <!-- Nav Item - Tables -->
            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>



        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <form class="form-inline">
                        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                            <i class="fa fa-bars"></i>
                        </button>
                    </form>

                    <!-- Topbar Search -->
                    <form
                        class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                        <div class="input-group">
                            <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..."
                                aria-label="Search" aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="button">
                                    <i class="fas fa-search fa-sm"></i>
                                </button>
                            </div>
                        </div>
                    </form>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Listagem de Tipos de Produtos</h1>


                    <!-- DataTales Example -->


                    <?php
                    // Configurações do banco de dados
                                        require_once 'servidor.php';
                                        // Conexão com o banco de dados
                                        $serverName = $conteudoServidor; 
                                        $connectionOptions = array(
                                            "Database" => "sistema", // Nome do banco de dados
                                            //"Uid" => "yadmin", // Nome de usuário
                                            //"PWD" => "admin" // Senha
                                        );

                    // Conexão com o banco de dados
                    $conn = sqlsrv_connect($serverName, $connectionOptions);

                    // Verificar conexão
                    if ($conn === false) {
                        die(print_r(sqlsrv_errors(), true));
                    }

                    // Consulta para obter os dados da tabela imposto
                    $sql = "SELECT id, descricao, percentual FROM imposto";
                    $stmt = sqlsrv_query($conn, $sql);

                    // Verificar consulta
                    if ($stmt === false) {
                        die(print_r(sqlsrv_errors(), true));
                    }
                    ?>



                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <button class="btn btn-primary" type="button" data-bs-toggle="offcanvas"
                                data-bs-target="#offcanvasRight" aria-controls="offcanvasRight">+ Novo</button>

                            <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRight"
                                aria-labelledby="offcanvasRightLabel">
                                <div class="offcanvas-header">
                                    <h5 class="offcanvas-title" id="offcanvasRightLabel">Formulário de Tipos de Produtos
                                    </h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas"
                                        aria-label="Close"></button>
                                </div>
                                <div class="offcanvas-body">

                                    <form class="user" action="tipo_produto.php" method="post">
                                        <input type="hidden" id="ids_impostos" name="impostos_selecionados">

                                        <div class="form-group row">
                                            <div class="col-sm-6 mb-3 mb-sm-0">
                                                <label class="form-check-label label-right" for=" status">Id</label>
                                                <input type="text" class="form-control form-control-user" id="id"
                                                    name="id" placeholder="Id" readonly>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="form-check form-switch">
                                                    <label class="form-check-label" for="customSwitch"
                                                        style="margin-left: 20px; margin-top: 10px;">Ativo</label>
                                                    <input class="form-check-input" type="checkbox"
                                                        style="margin-left: 15px;  margin-top: 14px;" name="status"
                                                        id="status" checked>
                                                </div>
                                            </div>

                                            <hr>
                                            <div class="col-sm-12">
                                                <label class="form-check-label label-right"
                                                    for=" status">Descrição</label>
                                                <input type="text" class="form-control form-control-user" id="descricao"
                                                    name="descricao" placeholder="Descrição *">
                                            </div>

                                            <hr>
                                            <hr>
                                            <label class="form-check-label label-right" for=" status">Impostos</label>
                                            <div class="btn-group btn-group-custom" role="group"
                                                aria-label="Basic checkbox toggle button group">
                                                <?php
                                                // Verificar se há resultados e gerar os checkboxes e labels dinamicamente
                                                if (sqlsrv_has_rows($stmt)) {
                                                    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
                                                        echo '<input type="checkbox" class="btn-check" id="btncheck' . $row["id"] . '" name="impostos[]" value="' . $row["id"] . '" data-value="' . $row["percentual"] . '">';
                                                        echo '<label class="btn btn-outline-primary" for="btncheck' . $row["id"] . '" style="border-radius: 12px;">' . $row["descricao"] . '</label>';
                                                    }
                                                } else {
                                                    echo "0 results";
                                                }
                                                ?>
                                            </div>

                                        </div>
                                        <div class="form-group">
                                            <label class="form-check-label label-right" for=" status">Total
                                                Impostos</label>
                                            <input type="text" class="form-control form-control-user" id="total_imposto"
                                                readonly name="total_imposto" placeholder="Total Imposto" value="0.00"
                                                style="text-align: right;">
                                        </div>
                                        <hr class="sidebar-divider"
                                            style="margin-top: 30px;margin: 50px -20px 20px; border: 0; border-top: 1px solid #8c8c8c">
                                        <div style="margin-top: 30px;">
                                            <div class="col-sm-6 mb-3 mb-sm-0" style="float: left;">
                                                <button type="submit" name="salvar_tipo_poduto"
                                                    class="btn btn-success btn-user btn-block">
                                                    <i class="fas fa-save fa-fw"></i> Salvar
                                                </button>
                                            </div>
                                            <div class="col-sm-6" style="float: left;">
                                                <a href="#" class="btn btn-info btn-user btn-block"
                                                    onclick="limparFormulario()">
                                                    <i class="fas fa-eraser fa-fw"></i> Limpar
                                                </a>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php
                    // Fechar a conexão com o banco de dados
                    sqlsrv_close($conn);
                    ?>

                    <!-- /.container-fluid -->

                    <!-- Grid com ação -->

                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Listagem de Impostos</h6>
                        </div>




                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th style="text-align: center;width: 5%;">Editar</th>
                                            <th style="text-align: center;width: 5%;">Excluir</th>
                                            <th style="text-align: center;width: 5%;">Id</th>
                                            <th style="width: 65%;">Descrição</th>
                                            <th style="text-align: center;width: 15%;">Total Imposto (%)</th>
                                            <th style="text-align: center;width: 5%;">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        // Conexão com o banco de dados
                                        require_once 'servidor.php';
                                        // Conexão com o banco de dados
                                        $serverName = $conteudoServidor; 
                                        $connectionOptions = array(
                                            "Database" => "sistema", // Nome do banco de dados
                                            //"Uid" => "yadmin", // Nome de usuário
                                            //"PWD" => "admin" // Senha
                                        );

                                        try {
                                            // Estabelecendo a conexão
                                            $conn = sqlsrv_connect($serverName, $connectionOptions);

                                            if ($conn === false) {
                                                throw new Exception("Erro ao conectar ao banco de dados: " . print_r(sqlsrv_errors(), true));
                                            }

                                            // Verifica se o parâmetro id está presente na requisição GET
                                            if (isset($_GET['delete_id'])) {
                                                $delete_id = filter_input(INPUT_GET, 'delete_id', FILTER_SANITIZE_NUMBER_INT);

                                                // Query para excluir a linha correspondente ao id fornecido
                                                $sql_delete = "DELETE FROM sistema.dbo.tipo_produto WHERE id = ?";
                                                $params = array($delete_id);
                                                $stmt_delete = sqlsrv_query($conn, $sql_delete, $params);

                                                if ($stmt_delete === false) {
                                                    throw new Exception("Erro ao excluir registro do banco de dados: " . print_r(sqlsrv_errors(), true));
                                                }

                                                // Redirecionamento após a exclusão (opcional)
                                                // header("Location: nome_da_pagina.php");
                                                // exit();
                                            }

                                            // Verifica se o parâmetro edit_id está presente na requisição GET
                                            if (isset($_GET['edit_id'])) {
                                                $edit_id = filter_input(INPUT_GET, 'edit_id', FILTER_SANITIZE_NUMBER_INT);

                                                // Query para buscar os dados do registro a ser editado
                                                $sql_select = "SELECT id, descricao, total_imposto, status FROM sistema.dbo.tipo_produto WHERE id = ?";
                                                $params_select = array($edit_id);
                                                $stmt_select = sqlsrv_query($conn, $sql_select, $params_select);

                                                if ($stmt_select === false) {
                                                    throw new Exception("Erro ao buscar registro do banco de dados: " . print_r(sqlsrv_errors(), true));
                                                }

                                                // Extrai os dados do registro
                                                $row = sqlsrv_fetch_array($stmt_select, SQLSRV_FETCH_ASSOC);

                                                // Inicializa variáveis com os dados para o formulário de edição
                                                $id = $row['id'];
                                                $descricao = $row['descricao'];
                                                $total_imposto = $row['total_imposto'];
                                                $status = $row['status'];

                                                sqlsrv_free_stmt($stmt_select);
                                            }

                                            // Query para selecionar os dados da tabela tipo_produto
                                            $sql = "SELECT id, descricao, total_imposto, status FROM sistema.dbo.tipo_produto";
                                            $stmt = sqlsrv_query($conn, $sql);

                                            if ($stmt === false) {
                                                throw new Exception("Erro ao executar a consulta SQL: " . print_r(sqlsrv_errors(), true));
                                            }

                                            // Iterando sobre os resultados da consulta
                                            while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
                                                echo "<tr>";
                                                echo "<td style='text-align: center; width: 5%;'>
                                                        <a href='#' class='edit-btn' data-bs-toggle='offcanvas' data-bs-target='#offcanvasRight' data-id='" . $row['id'] . "' title='Editar'>
                                                            <i class='fas fa-edit' style='color: #4E73DF;'></i>
                                                        </a>
                                                    </td>";
                                                echo "<td style='text-align: center; width: 5%;'>
                                                        <a href='?delete_id=" . $row['id'] . "' onclick='return confirm(\"Tem certeza que deseja excluir este registro?\");' title='Excluir'>
                                                            <i class='fas fa-trash-alt' style='color: #f69697;'></i>
                                                        </a>
                                                    </td>";
                                                echo "<td style='text-align: center; width: 5%;'>" . $row['id'] . "</td>";
                                                echo "<td style='width: 70%;'>" . $row['descricao'] . "</td>";
                                                echo "<td style='text-align: center; width: 10%;'>" . $row['total_imposto'] . "</td>";
                                                echo "<td style='color: " . ($row['status'] == 'A' ? 'green' : 'red') . "; text-align: center; width: 5%;'>" . ($row['status'] == 'A' ? 'Ativo' : 'Inativo') . "</td>";
                                                echo "</tr>";
                                            }

                                            sqlsrv_free_stmt($stmt);
                                            sqlsrv_close($conn);

                                        } catch (Exception $e) {
                                            echo "<tr><td colspan='6'>Erro ao carregar dados: " . $e->getMessage() . "</td></tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- Offcanvas para formulário de edição -->
                    <!-- Formulário de edição dentro do offcanvas -->

                    <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRight"
                        aria-labelledby="offcanvasRightLabel">
                        <div class="offcanvas-header">
                            <h5 class="offcanvas-title" id="offcanvasRightLabel">Formulário de Tipos de Produtos</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="offcanvas"
                                aria-label="Close"></button>
                        </div>
                        <div class="offcanvas-body">
                            <form class="user" action="tipos_produtos_salvar.php" method="post">
                                <!-- Campo oculto para o ID do registro -->
                                <input type="hidden" id="id" name="id" value="">

                                <!-- Demais campos do formulário -->
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control form-control-user" id="descricao"
                                            name="descricao" placeholder="Descrição *">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control form-control-user" id="total_imposto"
                                        name="total_imposto" placeholder="Total Imposto" min="1" max="100" step="0.01"
                                        value="1.00">
                                </div>
                                <div class="form-group">
                                    <div class="form-check form-switch">
                                        <label class="form-check-label" for="status">Ativo</label>
                                        <input class="form-check-input" type="checkbox" id="status" name="status"
                                            checked>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="submit" name="salvar_tipo_produto"
                                        class="btn btn-success btn-user btn-block">
                                        <i class="fas fa-save fa-fw"></i> Salvar
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>


                    <script>
                        document.addEventListener('DOMContentLoaded', function () {
                            var checkboxes = document.querySelectorAll('.btn-check');
                            var totalImposto = document.getElementById('total_imposto');

                            checkboxes.forEach(function (checkbox) {
                                checkbox.addEventListener('change', function () {
                                    var total = 0;
                                    checkboxes.forEach(function (cb) {
                                        if (cb.checked) {
                                            total += parseFloat(cb.getAttribute('data-value'));
                                        }
                                    });
                                    totalImposto.value = total.toFixed(2);
                                });
                            });

                            // JavaScript para ativar o offcanvas ao clicar no botão de edição
                            var editButtons = document.querySelectorAll('.edit-btn');
                            editButtons.forEach(function (button) {
                                button.addEventListener('click', function (event) {
                                    event.preventDefault(); // Evita a ação padrão do link

                                    var id = this.getAttribute('data-id'); // Obtém o ID do registro

                                    // Requisição AJAX para buscar os dados do registro
                                    var xhr = new XMLHttpRequest();
                                    xhr.onreadystatechange = function () {
                                        if (xhr.readyState === XMLHttpRequest.DONE) {
                                            if (xhr.status === 200) {
                                                var data = JSON.parse(xhr.responseText);

                                                // Preenche os campos do formulário de offcanvas com os dados do registro
                                                document.getElementById('id').value = data.id;
                                                document.getElementById('descricao').value = data.descricao;
                                                document.getElementById('total_imposto').value = data.total_imposto;
                                                document.getElementById('status').checked = data.status === 'A';

                                                // Marca os checkboxes dos impostos selecionados
                                                checkboxes.forEach(function (cb) {
                                                    cb.checked = data.impostos_selecionados.includes(parseInt(cb.value));
                                                });

                                                // Exibe o offcanvas
                                                var offcanvas = new bootstrap.Offcanvas(document.getElementById('offcanvasRight'));
                                                offcanvas.show();
                                            } else {
                                                console.error('Erro ao buscar dados do registro');
                                            }
                                        }
                                    };

                                    // Define a URL da requisição AJAX para buscar os dados do registro
                                    var url = 'tipo_produto_listar.php?id=' + encodeURIComponent(id);
                                    xhr.open('GET', url);
                                    xhr.send();
                                });
                            });
                        });
                    </script>




                    <!--Fim -  Grid com ação -->

                </div>
                <!-- End of Main Content -->
            </div>
            <!-- End of Content Wrapper -->

        </div>
        <!-- End of Page Wrapper -->

        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>

        <!-- Logout Modal-->
        <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <a class="btn btn-primary" href="login.html">Logout</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- limpa os dados do formulariot-->
        <script>
            function limparFormulario() {
                document.getElementById("id").value = ""; // Limpa o campo ID
                document.getElementById("status").checked = true; // Marca o checkbox como ativo
                document.getElementById("descricao").value = ""; // Limpa o campo Descrição
                document.getElementById("total_imposto").value = "0.00"; // Reseta o valor padrão no campo Total Imposto

                // Desmarca todos os checkboxes
                var checkboxes = document.querySelectorAll('.btn-check');
                checkboxes.forEach(function (checkbox) {
                    checkbox.checked = false;
                });
            }
        </script>

        <!-- Bootstrap core JavaScript-->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Core plugin JavaScript-->
        <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

        <!-- Custom scripts for all pages-->
        <script src="js/sb-admin-2.min.js"></script>

        <!-- Page level plugins -->
        <script src="vendor/datatables/jquery.dataTables.min.js"></script>
        <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

        <!-- Page level custom scripts -->
        <script src="js/demo/datatables-demo.js"></script>

        <!-- Scripts no final do body -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

        <!-- Calculo da soma do percentual - Botões -->
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                var checkboxes = document.querySelectorAll('.btn-check');
                var totalImposto = document.getElementById('total_imposto');

                checkboxes.forEach(function (checkbox) {
                    checkbox.addEventListener('change', function () {
                        var total = 0;
                        checkboxes.forEach(function (cb) {
                            if (cb.checked) {
                                total += parseFloat(cb.getAttribute('data-value'));
                            }
                        });
                        totalImposto.value = total.toFixed(2);
                    });
                });
            });
        </script>

        >



</body>

</html>

<?php

// Função para gravar dados no banco de dados
function gravarDados($serverName, $connectionOptions, $sql, $params = null)
{
    try {
        $conn = sqlsrv_connect($serverName, $connectionOptions);

        if ($conn === false) {
            throw new Exception("Erro ao conectar ao banco de dados: " . print_r(sqlsrv_errors(), true));
        }

        // Preparando e executando a consulta SQL
        $stmt = sqlsrv_query($conn, $sql, $params);

        if ($stmt === false) {
            throw new Exception("Erro ao executar a consulta SQL: " . print_r(sqlsrv_errors(), true));
        }

        // Fechando a conexão e liberando recursos
        sqlsrv_free_stmt($stmt);
        sqlsrv_close($conn);

        return true;
    } catch (Exception $e) {
        echo "<script>alert('Ocorreu um erro: " . $e->getMessage() . "');</script>";
        return false;
    }
}

// Verifica se o formulário foi submetido
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once 'servidor.php';
    // Conexão com o banco de dados
    $serverName = $conteudoServidor; 
    $connectionOptions = array(
        "Database" => "sistema", // Nome do banco de dados
        //"Uid" => "yadmin", // Nome de usuário
        //"PWD" => "admin" // Senha
    );

    // Obtém os dados do formulário
    $id = isset($_POST['id']) && !empty($_POST['id']) ? (int) $_POST['id'] : null;
    $descricao = $_POST['descricao'];
    $total_imposto = floatval($_POST['total_imposto']);
    $status = isset($_POST['status']) ? 'A' : 'I'; // 'A' para ativo, 'I' para inativo

    if ($id !== null && $id > 0) {
        // ID presente e maior que 0, atualiza o registro existente
        $sql = "UPDATE sistema.dbo.tipo_produto SET descricao = ?, total_imposto = ?, status = ? WHERE id = ?";
        $params = array($descricao, $total_imposto, $status, $id);
    } else {
        // ID não presente ou igual a 0, insere um novo registro
        $sql = "INSERT INTO sistema.dbo.tipo_produto (descricao, total_imposto, status) VALUES (?, ?, ?)";
        $params = array($descricao, $total_imposto, $status);
    }

    // Chama a função para gravar os dados no banco
    if (gravarDados($serverName, $connectionOptions, $sql, $params)) {
        // Se um novo registro foi inserido, obter o ID gerado
        if ($id === null || $id === 0) {
            $conn = sqlsrv_connect($serverName, $connectionOptions);
            $sql = "SELECT MAX(ID) AS id FROM tipo_produto";
            $stmt = sqlsrv_query($conn, $sql);
            if ($stmt === false) {
                die(print_r(sqlsrv_errors(), true));
            }
            $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
            $id = $row['id'];
            sqlsrv_free_stmt($stmt);
            sqlsrv_close($conn);
        }

        // Obter os IDs dos impostos selecionados
        $impostosSelecionados = isset($_POST['impostos']) ? $_POST['impostos'] : array();

        // Conectar novamente ao banco de dados
        $conn = sqlsrv_connect($serverName, $connectionOptions);
        if ($conn === false) {
            die(print_r(sqlsrv_errors(), true));
        }

        // Limpar entradas anteriores na tabela tipo_produto_imposto para evitar duplicidades
        $sql = "DELETE FROM sistema.dbo.tipo_produto_imposto WHERE id_tipo_produto = ?";
        $params = array($id);
        sqlsrv_query($conn, $sql, $params);

        echo "<pre>";
        print_r($impostosSelecionados);
        echo "</pre>";
        // Inserir os dados na tabela tipo_produto_imposto
        if (!empty($impostosSelecionados)) {
            foreach ($impostosSelecionados as $id_imposto) {
                $sql = "INSERT INTO sistema.dbo.tipo_produto_imposto (id_tipo_produto, id_imposto) VALUES (?, ?)";
                $params = array($id, $id_imposto);
                sqlsrv_query($conn, $sql, $params);
            }
        }

        // Fechar a conexão
        sqlsrv_close($conn);

        echo "<script>alert('Dados salvos com sucesso!');</script>";
        echo "<script>window.location = 'tipo_produto.php';</script>";
        exit; // Encerra o script após o redirecionamento
    }

    // Redireciona para a página adequada após salvar (opcional)
    // header("Location: tipo_produto_listar.php");
    // exit();
}
?>