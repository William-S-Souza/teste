<?php
// Conexão com o banco de dados
require_once 'servidor.php';
// Conexão com o banco de dados
$serverName = $conteudoServidor; 
$connectionOptions = array(
    "Database" => "sistema", // Nome do banco de dados
    //"Uid" => "yadmin", // Nome de usuário
    //"PWD" => "admin" // Senha
);

// Obtém o ID do tipo_produto da requisição GET
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    try {
        $conn = sqlsrv_connect($serverName, $connectionOptions);

        if ($conn === false) {
            throw new Exception("Erro ao conectar ao banco de dados: " . print_r(sqlsrv_errors(), true));
        }

        // Query para buscar os dados do tipo_produto
        $sql_tipo_produto = "SELECT tp.id, tp.descricao, tp.total_imposto, tp.status, 
            tpi.id_imposto
            FROM sistema.dbo.tipo_produto tp
            LEFT JOIN sistema.dbo.tipo_produto_imposto tpi ON tp.id = tpi.id_tipo_produto
            WHERE tp.id = ?";
        $params_tipo_produto = array($id);
        $stmt_tipo_produto = sqlsrv_query($conn, $sql_tipo_produto, $params_tipo_produto);

        if ($stmt_tipo_produto === false) {
            throw new Exception("Erro ao executar a consulta SQL do tipo_produto: " . print_r(sqlsrv_errors(), true));
        }

        $tipo_produto = array();
        $impostos_selecionados = array();

        while ($row = sqlsrv_fetch_array($stmt_tipo_produto, SQLSRV_FETCH_ASSOC)) {
            // Preenche os dados do tipo_produto
            $tipo_produto['id'] = $row['id'];
            $tipo_produto['descricao'] = $row['descricao'];
            $tipo_produto['total_imposto'] = $row['total_imposto'];
            $tipo_produto['status'] = $row['status'];

            // Preenche os impostos selecionados
            if ($row['id_imposto'] !== null) {
                $impostos_selecionados[] = $row['id_imposto'];
            }
        }

        // Adiciona os impostos selecionados ao array de retorno
        $tipo_produto['impostos_selecionados'] = $impostos_selecionados;

        // Libera o statement
        sqlsrv_free_stmt($stmt_tipo_produto);

        // Fecha a conexão
        sqlsrv_close($conn);

        // Retorna os dados como JSON
        header('Content-Type: application/json');
        echo json_encode($tipo_produto);
        exit;

    } catch (Exception $e) {
        // Trata erros
        http_response_code(500); // Erro interno do servidor
        echo json_encode(array('error' => $e->getMessage()));
        exit;
    }
}

// Se não houver ID válido, retorna erro
http_response_code(400);
echo json_encode(array('error' => 'ID do tipo_produto não especificado'));
exit;
?>
