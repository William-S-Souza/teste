<?php
// Conexão com o banco de dados
require_once 'servidor.php';
// Conexão com o banco de dados
$serverName = $conteudoServidor; 
$connectionOptions = array(
    "Database" => "sistema", // Nome do banco de dados
    //"Uid" => "yadmin", // Nome de usuário
    //"PWD" => "admin" // Senha
);

try {
    $conn = sqlsrv_connect($serverName, $connectionOptions);

    if ($conn === false) {
        throw new Exception("Erro ao conectar ao banco de dados: " . print_r(sqlsrv_errors(), true));
    }

    // Verifica se o parâmetro id foi passado na URL
    if (!isset($_GET['id'])) {
        throw new Exception("ID da venda não fornecido na requisição.");
    }

    $id_venda = $_GET['id'];

    // Consulta SQL para obter os dados da venda e seus produtos associados
    $sql_venda = "SELECT v.id, v.total_imposto, v.valor_venda
                  FROM venda v
                  WHERE v.id = ?";

    $params_venda = array($id_venda);
    $stmt_venda = sqlsrv_query($conn, $sql_venda, $params_venda);

    if ($stmt_venda === false) {
        throw new Exception("Erro ao executar a consulta SQL para venda: " . print_r(sqlsrv_errors(), true));
    }

    // Extrai os dados da venda
    $venda = sqlsrv_fetch_array($stmt_venda, SQLSRV_FETCH_ASSOC);

    // Consulta SQL para obter os produtos da venda
    $sql_produtos = "SELECT vp.id, vp.id_venda, vp.id_produto, vp.quantidade, vp.imposto, vp.valor, vp.valor_imposto, vp.valor_total
                     FROM venda_produto vp
                     WHERE vp.id_venda = ?";

    $params_produtos = array($id_venda);
    $stmt_produtos = sqlsrv_query($conn, $sql_produtos, $params_produtos);

    if ($stmt_produtos === false) {
        throw new Exception("Erro ao executar a consulta SQL para produtos da venda: " . print_r(sqlsrv_errors(), true));
    }

    // Monta o resultado em um array estruturado
    $result = array(
        'venda' => $venda,
        'produtos' => array()
    );

    // Extrai os dados dos produtos da venda
    while ($row_produtos = sqlsrv_fetch_array($stmt_produtos, SQLSRV_FETCH_ASSOC)) {
        $result['produtos'][] = $row_produtos;
    }

    // Retorna os dados como JSON
    header('Content-Type: application/json');
    echo json_encode($result);
    exit;

    sqlsrv_free_stmt($stmt_venda);
    sqlsrv_free_stmt($stmt_produtos);
    sqlsrv_close($conn);

} catch (Exception $e) {
    // Trata erros
    http_response_code(500); // Erro interno do servidor
    echo json_encode(array('error' => $e->getMessage()));
    exit;
}
?>

